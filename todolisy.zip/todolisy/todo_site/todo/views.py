from django.shortcuts import render, redirect
from django.contrib import messages

# from django.contrib.auth.decorators import login_required
# from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
# from django.contrib.auth import login 
# from django.contrib.auth import login as auth_login
from django.contrib.auth import logout


# import todo form and models

from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from .forms import TodoForm, UserRegisterForm

from .forms import TodoForm
from .models import Todo

###############################################


def index(request):

    item_list = Todo.objects.order_by("-date")
    if request.method == "POST":
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('todo')
    form = TodoForm()

    page = {
        "forms": form,
        "list": item_list,
        "title": "TODO LIST",
    }
    return render(request, 'todo/index.html', page)


### function to remove item, it receive todo item_id as primary key from url ##
def remove(request, item_id):
    item = Todo.objects.get(id=item_id)
    item.delete()
    messages.info(request, "item removed !!!")
    return redirect('todo')


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'todo/register.html', {'form': form})

@login_required
def dashboard(request):
    todos = Todo.objects.filter(user=request.user)
    form = TodoForm()
    return render(request, 'dashboard.html', {'todos': todos, 'form': form})

@login_required
def index(request):
    item_list = Todo.objects.order_by("-date")
    if request.method == "POST":
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('todo')
    form = TodoForm()

    page = {
        "forms": form,
        "list": item_list,
        "title": "TODO LIST",
    }
    return render(request, 'todo/index.html', page)

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('todo')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'todo/login.html')

def user_logout(request):
    logout(request)
    return redirect('login')




# def register(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             user = form.save()
#             login(request, user)
#             return redirect('todo')
#     else:
#         form = UserCreationForm()
#     return render(request, 'register.html', {'form': form})

# def login_view(request):
#     if request.method == 'POST':
#         form = AuthenticationForm(data=request.POST)
#         if form.is_valid():
#             user = form.get_user()
#             auth_login(request, user)
#             return redirect('todo')
#     else:
#         form = AuthenticationForm()
#     return render(request, 'login.html', {'form': form})



# @login_required
# def logout_view(request):
#     logout(request)
#     return redirect('todo')

