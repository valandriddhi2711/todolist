from django.urls import path
from .views import add_movie, show_movies, book_movie

urlpatterns = [
    path('add/', add_movie, name='add_movie'),
    path('list/', show_movies, name='show_movies'),
    path('book/<int:movie_id>/', book_movie, name='book_movie'),
]

