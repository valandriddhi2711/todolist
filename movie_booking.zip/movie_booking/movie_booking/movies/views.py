from django.shortcuts import render, redirect,get_list_or_404
from .models import Movie
from .forms import MovieForm
from django.contrib import messages

# Add Movie View
def add_movie(request):
    if request.method == 'POST':
        form = MovieForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Movie added successfully!')
            return redirect('add_movie')
    else:
        form = MovieForm()
    return render(request,'add_movie.html',{'form': form})

# Show All Movies View with Filtering
def show_movies(request):
    movies = Movie.objects.all()
    actors_filter = request.GET.get('actors')
    category_filter = request.GET.get('category')

    if actors_filter:
        movies = movies.filter(actors__icontains=actors_filter)
    if category_filter:
        movies = movies.filter(category__icontains=category_filter)

    return render(request, 'show_movies.html', {'movies': movies})

# Booking Movie View
def book_movie(request, movie_id):
    movie = Movie.objects.get(id=movie_id)
    if movie.booking_count < 5:
        movie.booking_count += 1
        movie.save()
        messages.success(request, 'Movie booked successfully!')
    else:
        messages.error(request, 'Booking not available for this movie.')
    return redirect('show_movies')
